/**
 * This script sets the Backstretch arguments in the Agency Pro Theme.
 *
 * @package Agency\JS
 * @author StudioPress
 * @license GPL-2.0+
 */
/* changed the duration from 3000 and the fade from 750 to 0 AC*/
jQuery(document).ready(function($) {
	$("body").backstretch([BackStretchImg.src],{duration:3000,fade:750});
});